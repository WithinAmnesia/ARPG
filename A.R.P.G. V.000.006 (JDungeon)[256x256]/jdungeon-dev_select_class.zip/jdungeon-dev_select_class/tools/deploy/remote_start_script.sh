#!/bin/bash

cd /root/web && docker-compose build && docker-compose up -d
