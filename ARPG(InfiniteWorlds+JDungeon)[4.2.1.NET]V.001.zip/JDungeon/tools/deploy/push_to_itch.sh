#!/bin/bash

butler push build/web/ $1:html5