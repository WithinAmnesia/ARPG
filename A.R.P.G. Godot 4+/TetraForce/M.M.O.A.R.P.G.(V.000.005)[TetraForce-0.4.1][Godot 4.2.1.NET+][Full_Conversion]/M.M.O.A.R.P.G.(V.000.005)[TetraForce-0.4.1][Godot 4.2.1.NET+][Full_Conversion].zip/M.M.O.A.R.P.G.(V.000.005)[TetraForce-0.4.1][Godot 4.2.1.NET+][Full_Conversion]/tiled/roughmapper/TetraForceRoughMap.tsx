<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="TetraForceRoughMap" tilewidth="8" tileheight="8" tilecount="36" columns="6">
 <image source="TetraForceRoughMap.png" width="48" height="48"/>
</tileset>
