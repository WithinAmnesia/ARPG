<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="dungeon_tileset" tilewidth="16" tileheight="16" tilecount="280" columns="5">
 <image source="../images/tilesets/dungeon_tileset.png" width="80" height="896"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="6" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="14">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="15">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="16">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="17">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="18">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="19">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="21">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="22">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="23">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="24">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="27">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="28">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="6" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="29">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="30">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="31">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="33">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="35">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="40">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="46">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="49">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="50">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="51">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="52">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="53">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="54">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="55">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="56">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="57">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="58">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="6" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="59">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="125">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="127">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="130">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="132">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="133">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="135">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="137">
  <objectgroup draworder="index" id="3">
   <object id="3" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="140">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="142">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="145">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="147">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="150">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="152">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="155">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="157">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="160">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="162">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="165">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="16">
    <polygon points="0,0 0,-16 16,-16 16.0909,-8 7.90909,-8 8.09091,-0.0909091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="166">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="167">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0">
    <polygon points="0,0 -16,0 -15.9091,7.90909 -8.18182,7.81818 -8.09091,15.8182 -8.09091,16 0,16"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="168">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="8" width="8" height="8"/>
  </objectgroup>
 </tile>
 <tile id="169">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="8" height="8"/>
  </objectgroup>
 </tile>
 <tile id="170">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="172">
  <objectgroup draworder="index" id="3">
   <object id="2" x="8" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="173">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="0" width="8" height="8"/>
  </objectgroup>
 </tile>
 <tile id="174">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="8"/>
  </objectgroup>
 </tile>
 <tile id="176">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="177">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0">
    <polygon points="0,0 0,16 -16,16 -16,8.09091 -7.90909,8 -7.90909,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="180">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="181">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="182">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="183">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="185">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="186">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="187">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="188">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="0" width="8" height="16"/>
  </objectgroup>
 </tile>
 <tile id="191">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="193">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="194">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="195">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="196">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="198">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="199">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="200">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="201">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="202">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="203">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="204">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="205">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="206">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="207">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="208">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="209">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="210">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="211">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="212">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="213">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="214">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="215">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="216">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="217">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="218">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="219">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="220">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="221">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="222">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="223">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="16">
    <polygon points="0,0 11.1818,0 -0.0909091,-10.9091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="225">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="226">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="227">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="228">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="230">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="231">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="232">
  <objectgroup draworder="index" id="2">
   <object id="2" x="16" y="16">
    <polygon points="0,0 0.0909091,-10.8182 -11.1818,-0.0909091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="233">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="235">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="236">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="237">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="238">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="240">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="241">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="242">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="245">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="246">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="250">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="251">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="255">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="256">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="260">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="10"/>
  </objectgroup>
 </tile>
 <tile id="261">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="0" width="10" height="16"/>
  </objectgroup>
 </tile>
 <tile id="265">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="266">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="267">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="268">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="269">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="270">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="271">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="275">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="276">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <wangsets>
  <wangset name="Terrains" type="corner" tile="-1">
   <wangcolor name="Dungeon Wall 1" color="#ff0000" tile="11" probability="1"/>
   <wangcolor name="Dungeon Wall 2" color="#00ff00" tile="26" probability="1"/>
   <wangcolor name="Dungeon Wall 3" color="#0000ff" tile="41" probability="1"/>
   <wangcolor name="Dungeon Wall 4" color="#ff7700" tile="56" probability="1"/>
   <wangcolor name="Dungeon Floor 1" color="#00e9ff" tile="66" probability="1"/>
   <wangcolor name="Dungeon Floor 2" color="#ff00d8" tile="81" probability="1"/>
   <wangcolor name="Dungeon Floor 3" color="#ffff00" tile="96" probability="1"/>
   <wangcolor name="Dungeon Floor 4" color="#a000ff" tile="111" probability="1"/>
   <wangcolor name="Upper Bumper" color="#00ffa1" tile="176" probability="1"/>
   <wangcolor name="Deep Water" color="#ffa8a8" tile="203" probability="1"/>
   <wangcolor name="Hole" color="#b4a8ff" tile="218" probability="1"/>
   <wangtile tileid="0" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="4" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="5" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="6" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="7" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="8" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="9" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="10" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="11" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="12" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="15" wangid="0,0,0,2,0,0,0,0"/>
   <wangtile tileid="16" wangid="0,0,0,2,0,2,0,0"/>
   <wangtile tileid="17" wangid="0,0,0,0,0,2,0,0"/>
   <wangtile tileid="18" wangid="0,2,0,0,0,2,0,2"/>
   <wangtile tileid="19" wangid="0,2,0,2,0,0,0,2"/>
   <wangtile tileid="20" wangid="0,2,0,2,0,0,0,0"/>
   <wangtile tileid="21" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="22" wangid="0,0,0,0,0,2,0,2"/>
   <wangtile tileid="23" wangid="0,0,0,2,0,2,0,2"/>
   <wangtile tileid="24" wangid="0,2,0,2,0,2,0,0"/>
   <wangtile tileid="25" wangid="0,2,0,0,0,0,0,0"/>
   <wangtile tileid="26" wangid="0,2,0,0,0,0,0,2"/>
   <wangtile tileid="27" wangid="0,0,0,0,0,0,0,2"/>
   <wangtile tileid="30" wangid="0,0,0,3,0,0,0,0"/>
   <wangtile tileid="31" wangid="0,0,0,3,0,3,0,0"/>
   <wangtile tileid="32" wangid="0,0,0,0,0,3,0,0"/>
   <wangtile tileid="33" wangid="0,3,0,0,0,3,0,3"/>
   <wangtile tileid="34" wangid="0,3,0,3,0,0,0,3"/>
   <wangtile tileid="35" wangid="0,3,0,3,0,0,0,0"/>
   <wangtile tileid="36" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="37" wangid="0,0,0,0,0,3,0,3"/>
   <wangtile tileid="38" wangid="0,0,0,3,0,3,0,3"/>
   <wangtile tileid="39" wangid="0,3,0,3,0,3,0,0"/>
   <wangtile tileid="40" wangid="0,3,0,0,0,0,0,0"/>
   <wangtile tileid="41" wangid="0,3,0,0,0,0,0,3"/>
   <wangtile tileid="42" wangid="0,0,0,0,0,0,0,3"/>
   <wangtile tileid="45" wangid="0,0,0,4,0,0,0,0"/>
   <wangtile tileid="46" wangid="0,0,0,4,0,4,0,0"/>
   <wangtile tileid="47" wangid="0,0,0,0,0,4,0,0"/>
   <wangtile tileid="48" wangid="0,4,0,0,0,4,0,4"/>
   <wangtile tileid="49" wangid="0,4,0,4,0,0,0,4"/>
   <wangtile tileid="50" wangid="0,4,0,4,0,0,0,0"/>
   <wangtile tileid="51" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="52" wangid="0,0,0,0,0,4,0,4"/>
   <wangtile tileid="53" wangid="0,0,0,4,0,4,0,4"/>
   <wangtile tileid="54" wangid="0,4,0,4,0,4,0,0"/>
   <wangtile tileid="55" wangid="0,4,0,0,0,0,0,0"/>
   <wangtile tileid="56" wangid="0,4,0,0,0,0,0,4"/>
   <wangtile tileid="57" wangid="0,0,0,0,0,0,0,4"/>
   <wangtile tileid="60" wangid="0,0,0,5,0,0,0,0"/>
   <wangtile tileid="61" wangid="0,0,0,5,0,5,0,0"/>
   <wangtile tileid="62" wangid="0,0,0,0,0,5,0,0"/>
   <wangtile tileid="63" wangid="0,5,0,0,0,5,0,5"/>
   <wangtile tileid="64" wangid="0,5,0,5,0,0,0,5"/>
   <wangtile tileid="65" wangid="0,5,0,5,0,0,0,0"/>
   <wangtile tileid="66" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="67" wangid="0,0,0,0,0,5,0,5"/>
   <wangtile tileid="68" wangid="0,0,0,5,0,5,0,5"/>
   <wangtile tileid="69" wangid="0,5,0,5,0,5,0,0"/>
   <wangtile tileid="70" wangid="0,5,0,0,0,0,0,0"/>
   <wangtile tileid="71" wangid="0,5,0,0,0,0,0,5"/>
   <wangtile tileid="72" wangid="0,0,0,0,0,0,0,5"/>
   <wangtile tileid="75" wangid="0,0,0,6,0,0,0,0"/>
   <wangtile tileid="76" wangid="0,0,0,6,0,6,0,0"/>
   <wangtile tileid="77" wangid="0,0,0,0,0,6,0,0"/>
   <wangtile tileid="78" wangid="0,6,0,0,0,6,0,6"/>
   <wangtile tileid="79" wangid="0,6,0,6,0,0,0,6"/>
   <wangtile tileid="80" wangid="0,6,0,6,0,0,0,0"/>
   <wangtile tileid="81" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="82" wangid="0,0,0,0,0,6,0,6"/>
   <wangtile tileid="83" wangid="0,0,0,6,0,6,0,6"/>
   <wangtile tileid="84" wangid="0,6,0,6,0,6,0,0"/>
   <wangtile tileid="85" wangid="0,6,0,0,0,0,0,0"/>
   <wangtile tileid="86" wangid="0,6,0,0,0,0,0,6"/>
   <wangtile tileid="87" wangid="0,0,0,0,0,0,0,6"/>
   <wangtile tileid="90" wangid="0,0,0,7,0,0,0,0"/>
   <wangtile tileid="91" wangid="0,0,0,7,0,7,0,0"/>
   <wangtile tileid="92" wangid="0,0,0,0,0,7,0,0"/>
   <wangtile tileid="93" wangid="0,7,0,0,0,7,0,7"/>
   <wangtile tileid="94" wangid="0,7,0,7,0,0,0,7"/>
   <wangtile tileid="95" wangid="0,7,0,7,0,0,0,0"/>
   <wangtile tileid="96" wangid="0,7,0,7,0,7,0,7"/>
   <wangtile tileid="97" wangid="0,0,0,0,0,7,0,7"/>
   <wangtile tileid="98" wangid="0,0,0,7,0,7,0,7"/>
   <wangtile tileid="99" wangid="0,7,0,7,0,7,0,0"/>
   <wangtile tileid="100" wangid="0,7,0,0,0,0,0,0"/>
   <wangtile tileid="101" wangid="0,7,0,0,0,0,0,7"/>
   <wangtile tileid="102" wangid="0,0,0,0,0,0,0,7"/>
   <wangtile tileid="105" wangid="0,0,0,8,0,0,0,0"/>
   <wangtile tileid="106" wangid="0,0,0,8,0,8,0,0"/>
   <wangtile tileid="107" wangid="0,0,0,0,0,8,0,0"/>
   <wangtile tileid="108" wangid="0,8,0,0,0,8,0,8"/>
   <wangtile tileid="109" wangid="0,8,0,8,0,0,0,8"/>
   <wangtile tileid="110" wangid="0,8,0,8,0,0,0,0"/>
   <wangtile tileid="111" wangid="0,8,0,8,0,8,0,8"/>
   <wangtile tileid="112" wangid="0,0,0,0,0,8,0,8"/>
   <wangtile tileid="113" wangid="0,0,0,8,0,8,0,8"/>
   <wangtile tileid="114" wangid="0,8,0,8,0,8,0,0"/>
   <wangtile tileid="115" wangid="0,8,0,0,0,0,0,0"/>
   <wangtile tileid="116" wangid="0,8,0,0,0,0,0,8"/>
   <wangtile tileid="117" wangid="0,0,0,0,0,0,0,8"/>
   <wangtile tileid="165" wangid="0,0,0,9,0,0,0,0"/>
   <wangtile tileid="166" wangid="0,0,0,9,0,9,0,0"/>
   <wangtile tileid="167" wangid="0,0,0,0,0,9,0,0"/>
   <wangtile tileid="168" wangid="0,9,0,0,0,9,0,9"/>
   <wangtile tileid="169" wangid="0,9,0,9,0,0,0,9"/>
   <wangtile tileid="170" wangid="0,9,0,9,0,0,0,0"/>
   <wangtile tileid="171" wangid="0,9,0,9,0,9,0,9"/>
   <wangtile tileid="172" wangid="0,0,0,0,0,9,0,9"/>
   <wangtile tileid="173" wangid="0,0,0,9,0,9,0,9"/>
   <wangtile tileid="174" wangid="0,9,0,9,0,9,0,0"/>
   <wangtile tileid="175" wangid="0,9,0,0,0,0,0,0"/>
   <wangtile tileid="176" wangid="0,9,0,0,0,0,0,9"/>
   <wangtile tileid="177" wangid="0,0,0,0,0,0,0,9"/>
   <wangtile tileid="190" wangid="0,0,0,10,0,0,0,0"/>
   <wangtile tileid="191" wangid="0,0,0,10,0,10,0,0"/>
   <wangtile tileid="192" wangid="0,0,0,0,0,10,0,0"/>
   <wangtile tileid="193" wangid="0,10,0,0,0,10,0,10"/>
   <wangtile tileid="194" wangid="0,10,0,10,0,0,0,10"/>
   <wangtile tileid="195" wangid="0,10,0,10,0,0,0,0"/>
   <wangtile tileid="196" wangid="0,10,0,10,0,10,0,10"/>
   <wangtile tileid="197" wangid="0,0,0,0,0,10,0,10"/>
   <wangtile tileid="198" wangid="0,0,0,10,0,10,0,10"/>
   <wangtile tileid="199" wangid="0,10,0,10,0,10,0,0"/>
   <wangtile tileid="200" wangid="0,10,0,0,0,0,0,0"/>
   <wangtile tileid="201" wangid="0,10,0,0,0,0,0,10"/>
   <wangtile tileid="202" wangid="0,0,0,0,0,0,0,10"/>
   <wangtile tileid="205" wangid="0,0,0,11,0,0,0,0"/>
   <wangtile tileid="206" wangid="0,0,0,11,0,11,0,0"/>
   <wangtile tileid="207" wangid="0,0,0,0,0,11,0,0"/>
   <wangtile tileid="208" wangid="0,11,0,0,0,11,0,11"/>
   <wangtile tileid="209" wangid="0,11,0,11,0,0,0,11"/>
   <wangtile tileid="210" wangid="0,11,0,11,0,0,0,0"/>
   <wangtile tileid="211" wangid="0,11,0,11,0,11,0,11"/>
   <wangtile tileid="212" wangid="0,0,0,0,0,11,0,11"/>
   <wangtile tileid="213" wangid="0,0,0,11,0,11,0,11"/>
   <wangtile tileid="214" wangid="0,11,0,11,0,11,0,0"/>
   <wangtile tileid="215" wangid="0,11,0,0,0,0,0,0"/>
   <wangtile tileid="216" wangid="0,11,0,0,0,0,0,11"/>
   <wangtile tileid="217" wangid="0,0,0,0,0,0,0,11"/>
  </wangset>
 </wangsets>
</tileset>
