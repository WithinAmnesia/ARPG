---
name: 💡 Feature Request
about: Ideas to improve TetraForce
labels: 'request'
---

**Description**

<!-- Clear description of what you'd like to see. -->