#!/bin/sh

docker-compose --env-file ../../.env up -d